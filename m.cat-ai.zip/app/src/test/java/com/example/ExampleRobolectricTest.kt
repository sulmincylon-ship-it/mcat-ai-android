package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AppLanguage
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read app name string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("M.Cat AI", appName)
  }

  @Test
  fun `verify multilingual language resolution`() {
    assertEquals(AppLanguage.SINHALA, AppLanguage.fromCode("si"))
    assertEquals(AppLanguage.TAMIL, AppLanguage.fromCode("ta"))
    assertEquals(AppLanguage.ARABIC, AppLanguage.fromCode("ar"))
    assertEquals(true, AppLanguage.ARABIC.isRtl)
  }
}
