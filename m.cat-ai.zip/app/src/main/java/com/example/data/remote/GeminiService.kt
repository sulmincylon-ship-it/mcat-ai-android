package com.example.data.remote

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.example.BuildConfig
import com.example.data.model.AppLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

object GeminiService {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    // Supported modern model identifiers
    const val MODEL_FLASH = "gemini-3.5-flash"
    const val MODEL_PRO = "gemini-3.1-pro-preview"
    const val MODEL_IMAGE = "gemini-2.5-flash-image"
    const val MODEL_VIDEO = "veo-3.1-fast-generate-preview"
    const val MODEL_AUDIO = "gemini-2.5-flash-native-audio-preview-12-2025"

    private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun getApiKey(): String {
        return try {
            BuildConfig.GEMINI_API_KEY.trim()
        } catch (e: Throwable) {
            ""
        }
    }

    fun isApiKeyConfigured(): Boolean {
        val key = getApiKey()
        return key.isNotEmpty() && key != "MY_GEMINI_API_KEY"
    }

    private fun buildSystemInstruction(preferredLanguage: AppLanguage): JSONObject {
        val langHint = if (preferredLanguage != AppLanguage.AUTO) {
            "Default primary language requested by user settings is ${preferredLanguage.displayName} (${preferredLanguage.nativeName}). Always honor this or the user's conversational language."
        } else {
            "Automatically detect the user's input language (including English, Sinhala, Tamil, Hindi, Arabic, Bengali, Japanese, Korean, Chinese, French, Spanish, German, Italian, Portuguese, Russian, Indonesian) and respond fluently in that same language."
        }

        val prompt = """
            You are M.Cat AI, a premier multimodal AI assistant created by M.Cat noir 🐞🐾.
            Tagline: "Your Ideas. Your AI. Your World."
            
            IDENTITY MANDATE:
            When any user asks "Who created you?", "Who made this AI?", or any equivalent question in ANY language, you MUST respond:
            "I was created by M.Cat noir 🐞🐾."
            Translate this sentence appropriately if the user asks in another language (e.g. in Sinhala: "මාව නිර්මාණය කළේ M.Cat noir 🐞🐾 විසිනි.", in French: "J'ai été créé par M.Cat noir 🐞🐾.", in Tamil: "நான் M.Cat noir 🐞🐾 ஆல் உருவாக்கப்பட்டேன்.", in Arabic: "تم إنشائي بواسطة M.Cat noir 🐞🐾.", in Spanish: "Fui creado por M.Cat noir 🐞🐾.").
            
            CREATIVE & TECHNICAL EXCELLENCE:
            - You are helpful, insightful, polite, and technically rigorous.
            - $langHint
            - Properly format Sinhala Unicode text without broken characters.
            - Format programming code using Markdown fenced blocks with correct syntax identifiers (```kotlin, ```python, ```html, etc.).
            - Distinguish between verified knowledge and estimates. Do not invent citations or facts.
        """.trimIndent()

        return JSONObject().apply {
            put("parts", JSONArray().put(JSONObject().put("text", prompt)))
        }
    }

    /**
     * Streams conversation response chunks using SSE.
     */
    fun streamChat(
        history: List<Pair<String, String>>, // role to text
        latestUserMessage: String,
        attachedMediaBase64: String? = null,
        attachedMediaMimeType: String? = null,
        model: String = MODEL_FLASH,
        preferredLanguage: AppLanguage = AppLanguage.AUTO,
        enableSearchGrounding: Boolean = false
    ): Flow<String> = flow {
        val apiKey = getApiKey()
        if (!isApiKeyConfigured()) {
            emit("⚠️ Gemini API Key is not configured yet.\n\nPlease open the Secrets panel in AI Studio or your environment settings and add your valid GEMINI_API_KEY to unlock real-time AI responses.\n\nCreated by M.Cat noir 🐞🐾")
            return@flow
        }

        val url = "$BASE_URL/$model:streamGenerateContent?alt=sse&key=$apiKey"

        val contentsArray = JSONArray()

        // Append past conversation turns
        for ((role, text) in history) {
            val roleName = if (role.equals("USER", ignoreCase = true)) "user" else "model"
            val contentObj = JSONObject().apply {
                put("role", roleName)
                put("parts", JSONArray().put(JSONObject().put("text", text)))
            }
            contentsArray.put(contentObj)
        }

        // Current user message
        val currentParts = JSONArray()
        currentParts.put(JSONObject().put("text", latestUserMessage))

        if (!attachedMediaBase64.isNullOrEmpty() && !attachedMediaMimeType.isNullOrEmpty()) {
            val inlineData = JSONObject().apply {
                put("mimeType", attachedMediaMimeType)
                put("data", attachedMediaBase64)
            }
            currentParts.put(JSONObject().put("inlineData", inlineData))
        }

        contentsArray.put(JSONObject().apply {
            put("role", "user")
            put("parts", currentParts)
        })

        val requestJson = JSONObject().apply {
            put("contents", contentsArray)
            put("systemInstruction", buildSystemInstruction(preferredLanguage))
            if (enableSearchGrounding) {
                val toolsArray = JSONArray().apply {
                    put(JSONObject().put("googleSearch", JSONObject()))
                }
                put("tools", toolsArray)
            }
        }

        val request = Request.Builder()
            .url(url)
            .post(requestJson.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val errBody = response.body?.string() ?: ""
                val errMsg = try {
                    val errJson = JSONObject(errBody)
                    errJson.optJSONObject("error")?.optString("message") ?: errBody
                } catch (e: Exception) {
                    errBody
                }
                emit("Error (${response.code}): $errMsg")
                return@flow
            }

            val source = response.body?.source() ?: return@flow
            while (!source.exhausted()) {
                val line = source.readUtf8Line() ?: break
                val trimmed = line.trim()
                if (trimmed.startsWith("data:")) {
                    val payload = trimmed.removePrefix("data:").trim()
                    if (payload.isEmpty() || payload == "[DONE]") continue
                    try {
                        val chunkObj = JSONObject(payload)
                        val candidates = chunkObj.optJSONArray("candidates")
                        if (candidates != null && candidates.length() > 0) {
                            val candidate = candidates.getJSONObject(0)
                            val content = candidate.optJSONObject("content")
                            val parts = content?.optJSONArray("parts")
                            if (parts != null) {
                                for (i in 0 until parts.length()) {
                                    val part = parts.getJSONObject(i)
                                    val text = part.optString("text", "")
                                    if (text.isNotEmpty()) {
                                        emit(text)
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        // ignore malformed frame chunk
                    }
                }
            }
        }
    }.flowOn(Dispatchers.IO)

    /**
     * Generates an image using gemini-2.5-flash-image
     */
    suspend fun generateImage(
        prompt: String,
        aspectRatio: String = "1:1",
        referenceImageBase64: String? = null,
        referenceImageMimeType: String? = "image/jpeg"
    ): Result<GeneratedImageResult> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (!isApiKeyConfigured()) {
            return@withContext Result.failure(
                IllegalStateException("GEMINI_API_KEY is not configured in Secrets panel.")
            )
        }

        val url = "$BASE_URL/$MODEL_IMAGE:generateContent?key=$apiKey"

        try {
            val partsArray = JSONArray()
            partsArray.put(JSONObject().put("text", prompt))

            if (!referenceImageBase64.isNullOrEmpty() && !referenceImageMimeType.isNullOrEmpty()) {
                val inlineData = JSONObject().apply {
                    put("mimeType", referenceImageMimeType)
                    put("data", referenceImageBase64)
                }
                partsArray.put(JSONObject().put("inlineData", inlineData))
            }

            val contentsArray = JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", partsArray)
                })
            }

            val genConfig = JSONObject().apply {
                put("responseModalities", JSONArray().put("TEXT").put("IMAGE"))
                put("imageConfig", JSONObject().apply {
                    put("aspectRatio", aspectRatio)
                    put("imageSize", "1K")
                })
            }

            val requestJson = JSONObject().apply {
                put("contents", contentsArray)
                put("generationConfig", genConfig)
            }

            val request = Request.Builder()
                .url(url)
                .post(requestJson.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    val errMsg = try {
                        JSONObject(bodyStr).optJSONObject("error")?.optString("message") ?: bodyStr
                    } catch (e: Exception) {
                        bodyStr
                    }
                    return@withContext Result.failure(Exception("Image generation failed (${response.code}): $errMsg"))
                }

                val responseJson = JSONObject(bodyStr)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    return@withContext Result.failure(Exception("No image generated in candidate response."))
                }

                val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                var imageBase64: String? = null
                var mimeType: String = "image/png"
                var descriptionText = ""

                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        if (part.has("inlineData")) {
                            val inline = part.getJSONObject("inlineData")
                            imageBase64 = inline.optString("data")
                            mimeType = inline.optString("mimeType", "image/png")
                        } else if (part.has("text")) {
                            descriptionText += part.optString("text") + " "
                        }
                    }
                }

                if (imageBase64.isNullOrEmpty()) {
                    return@withContext Result.failure(Exception("Model did not return inline image data. Response: $descriptionText"))
                }

                Result.success(
                    GeneratedImageResult(
                        base64Data = imageBase64,
                        mimeType = mimeType,
                        description = descriptionText.trim()
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Submits a Video Generation request with Veo.
     */
    suspend fun generateVideo(
        prompt: String,
        aspectRatio: String = "16:9",
        resolution: String = "720p"
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (!isApiKeyConfigured()) {
            return@withContext Result.failure(
                IllegalStateException("GEMINI_API_KEY is not configured in Secrets panel.")
            )
        }

        val url = "$BASE_URL/$MODEL_VIDEO:generateVideos?key=$apiKey"

        try {
            val requestJson = JSONObject().apply {
                put("prompt", prompt)
                put("config", JSONObject().apply {
                    put("numberOfVideos", 1)
                    put("resolution", resolution)
                    put("aspectRatio", aspectRatio)
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(requestJson.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    val errMsg = try {
                        JSONObject(bodyStr).optJSONObject("error")?.optString("message") ?: bodyStr
                    } catch (e: Exception) {
                        bodyStr
                    }
                    return@withContext Result.failure(Exception("Veo API request failed (${response.code}): $errMsg"))
                }

                val json = JSONObject(bodyStr)
                val operationName = json.optString("name", "Operation started: $bodyStr")
                Result.success(operationName)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Generates audio/music with gemini-2.5-flash-native-audio-preview-12-2025
     */
    suspend fun generateAudio(
        prompt: String
    ): Result<GeneratedAudioResult> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (!isApiKeyConfigured()) {
            return@withContext Result.failure(
                IllegalStateException("GEMINI_API_KEY is not configured in Secrets panel.")
            )
        }

        val url = "$BASE_URL/$MODEL_AUDIO:generateContent?key=$apiKey"

        try {
            val requestJson = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", prompt)))
                }))
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().put("AUDIO"))
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(requestJson.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    val errMsg = try {
                        JSONObject(bodyStr).optJSONObject("error")?.optString("message") ?: bodyStr
                    } catch (e: Exception) {
                        bodyStr
                    }
                    return@withContext Result.failure(Exception("Audio generation failed (${response.code}): $errMsg"))
                }

                val responseJson = JSONObject(bodyStr)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    return@withContext Result.failure(Exception("No audio generated in candidate response."))
                }

                val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                var audioBase64: String? = null
                var mimeType: String = "audio/mp3"

                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        if (part.has("inlineData")) {
                            val inline = part.getJSONObject("inlineData")
                            audioBase64 = inline.optString("data")
                            mimeType = inline.optString("mimeType", "audio/mp3")
                        }
                    }
                }

                if (audioBase64.isNullOrEmpty()) {
                    return@withContext Result.failure(Exception("Audio model returned no inline audio data."))
                }

                Result.success(
                    GeneratedAudioResult(
                        base64Data = audioBase64,
                        mimeType = mimeType
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

data class GeneratedImageResult(
    val base64Data: String,
    val mimeType: String,
    val description: String
)

data class GeneratedAudioResult(
    val base64Data: String,
    val mimeType: String
)
