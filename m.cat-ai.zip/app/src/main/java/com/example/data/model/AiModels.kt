package com.example.data.model

enum class Role {
    USER,
    ASSISTANT,
    SYSTEM
}

enum class AiMode(val title: String, val description: String) {
    GENERAL("General Chat", "Multipurpose assistant for answers, reasoning, and tasks"),
    CODING("Coding Assistant", "Specialized in programming, debugging, and software architecture"),
    STUDY("Study & Tutor", "Step-by-step educational explanations, practice problems, and formulas"),
    RESEARCH("Web Research", "In-depth factual synthesis with web grounding capabilities"),
    TRANSLATION("Translator", "Polyglot translation, grammar nuances, and multilingual idioms")
}

data class AttachedMedia(
    val uriString: String,
    val mimeType: String,
    val base64Data: String? = null,
    val displayName: String = "Attachment"
)

enum class AppLanguage(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val isRtl: Boolean = false
) {
    AUTO("auto", "Auto Detect", "Auto Detect"),
    ENGLISH("en", "English", "English"),
    SINHALA("si", "Sinhala", "සිංහල"),
    TAMIL("ta", "Tamil", "தமிழ்"),
    HINDI("hi", "Hindi", "हिन्दी"),
    ARABIC("ar", "Arabic", "العربية", isRtl = true),
    BENGALI("bn", "Bengali", "বাংলা"),
    JAPANESE("ja", "Japanese", "日本語"),
    KOREAN("ko", "Korean", "한국어"),
    CHINESE("zh", "Chinese", "中文"),
    FRENCH("fr", "French", "Français"),
    SPANISH("es", "Spanish", "Español"),
    GERMAN("de", "German", "Deutsch"),
    ITALIAN("it", "Italian", "Italiano"),
    PORTUGUESE("pt", "Portuguese", "Português"),
    RUSSIAN("ru", "Russian", "Русский"),
    INDONESIAN("id", "Indonesian", "Bahasa Indonesia");

    companion object {
        fun fromCode(code: String): AppLanguage =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: AUTO
    }
}
