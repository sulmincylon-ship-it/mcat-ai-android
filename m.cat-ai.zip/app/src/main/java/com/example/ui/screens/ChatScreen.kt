package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.local.entity.MessageEntity
import com.example.data.model.AiMode
import com.example.ui.components.ChatBubbleItem
import com.example.ui.components.ChatInputBar
import com.example.ui.components.SuggestedPromptRow
import com.example.ui.theme.BorderHighlight
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.LadybugRed
import com.example.ui.theme.NoirDarkBg
import com.example.ui.viewmodel.MainViewModel

@Composable
fun ChatScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val messages by viewModel.messages.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val streamingText by viewModel.streamingAssistantText.collectAsState()
    val attachedMedia by viewModel.attachedMedia.collectAsState()
    val currentMode by viewModel.currentMode.collectAsState()
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val isListening by viewModel.voiceService.isListening.collectAsState()
    val isSpeaking by viewModel.voiceService.isSpeaking.collectAsState()
    val speechError by viewModel.voiceService.speechError.collectAsState()

    var inputMessageText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Photo picker launcher (zero-permission Android Photo Picker)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.attachMedia(uri, context)
        }
    }

    // Microphone permission launcher
    val recordAudioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.voiceService.startListening(selectedLanguage)
        } else {
            Toast.makeText(context, "Microphone permission is required for voice input", Toast.LENGTH_SHORT).show()
        }
    }

    // Scroll to bottom on new message
    LaunchedEffect(messages.size, streamingText) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size)
        }
    }

    // Show speech error notice
    LaunchedEffect(speechError) {
        speechError?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NoirDarkBg)
            .imePadding()
    ) {
        // Mode Selector Pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (mode in AiMode.entries) {
                val isSelected = mode == currentMode
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) CyanNeon else Color(0xFF141624))
                        .border(1.dp, if (isSelected) CyanNeon else BorderHighlight, RoundedCornerShape(12.dp))
                        .clickable { viewModel.setAiMode(mode) }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                        .testTag("mode_pill_${mode.name}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = mode.title,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isSelected) Color(0xFF001F29) else Color.White.copy(0.8f),
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    )
                }
            }
        }

        // Active chat message stream or Welcome Screen
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (messages.isEmpty() && streamingText.isEmpty()) {
                // Empty state / Welcome screen
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    item {
                        // Hero Banner Card
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .border(1.dp, BorderHighlight, RoundedCornerShape(18.dp))
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.mcat_hero_banner_1791901714989),
                                contentDescription = "M.Cat AI Hero Banner",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Title & Tagline
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "M.Cat AI",
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "🐞🐾", fontSize = 22.sp)
                        }

                        Text(
                            text = "Created by M.Cat noir 🐞🐾",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = LadybugRed,
                                fontWeight = FontWeight.SemiBold
                            ),
                            modifier = Modifier.padding(top = 2.dp)
                        )

                        Text(
                            text = "Your Ideas. Your AI. Your World.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = CyanNeon.copy(alpha = 0.9f)
                            ),
                            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                        )

                        // Multilingual Greeting
                        Text(
                            text = "Hello! • ආයුබෝවන්! • வணக்கம்! • مرحبا! • Bonjour! • Hola!",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.6f),
                                textAlign = TextAlign.Center
                            ),
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Suggested prompts
                        SuggestedPromptRow(
                            onSelectPrompt = { prompt ->
                                viewModel.sendMessage(prompt)
                            }
                        )
                    }
                }
            } else {
                // Messages List
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        val isLatestMsg = msg.id == messages.lastOrNull()?.id
                        ChatBubbleItem(
                            message = msg,
                            isLatest = isLatestMsg && !isGenerating,
                            isStreaming = false,
                            isSpeaking = isSpeaking,
                            onSpeak = { text -> viewModel.voiceService.speak(text, selectedLanguage) },
                            onStopSpeak = { viewModel.voiceService.stopSpeaking() },
                            onRegenerate = { viewModel.regenerateLatest() },
                            onEditPrompt = { prompt -> inputMessageText = prompt }
                        )
                    }

                    // Active live streaming chunk bubble
                    if (isGenerating && streamingText.isNotEmpty()) {
                        item {
                            val liveMessage = remember(streamingText) {
                                MessageEntity(
                                    id = "live_stream",
                                    conversationId = viewModel.activeConversationId.value ?: "",
                                    role = "ASSISTANT",
                                    content = streamingText
                                )
                            }
                            ChatBubbleItem(
                                message = liveMessage,
                                isLatest = true,
                                isStreaming = true,
                                isSpeaking = false
                            )
                        }
                    }
                }
            }
        }

        // Chat Input Bar
        ChatInputBar(
            inputText = inputMessageText,
            onInputTextChange = { inputMessageText = it },
            isGenerating = isGenerating,
            isListening = isListening,
            attachedMedia = attachedMedia,
            onAttachClick = {
                photoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onRemoveAttachment = { viewModel.clearAttachment() },
            onMicClick = {
                if (isListening) {
                    viewModel.voiceService.stopListening()
                } else {
                    val permissionCheck = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.RECORD_AUDIO
                    )
                    if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                        viewModel.voiceService.startListening(selectedLanguage)
                    } else {
                        recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }
            },
            onSendClick = {
                val text = inputMessageText.trim()
                inputMessageText = ""
                viewModel.sendMessage(text)
            },
            onStopClick = { viewModel.stopGeneration() }
        )
    }
}
