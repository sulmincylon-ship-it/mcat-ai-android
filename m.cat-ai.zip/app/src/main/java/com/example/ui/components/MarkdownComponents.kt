package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CodeBlockBg
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.LadybugRed
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun FormattedAssistantMessage(
    text: String,
    modifier: Modifier = Modifier
) {
    val blocks = remember(text) { parseMarkdownBlocks(text) }

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (block in blocks) {
            when (block) {
                is MarkdownBlock.Code -> {
                    CodeBlockCard(
                        code = block.code,
                        language = block.language
                    )
                }
                is MarkdownBlock.Paragraph -> {
                    MarkdownParagraph(text = block.text)
                }
                is MarkdownBlock.Header -> {
                    Text(
                        text = block.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = CyanNeon
                        ),
                        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun CodeBlockCard(
    code: String,
    language: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var copied by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CodeBlockBg)
            .padding(top = 6.dp, bottom = 8.dp)
    ) {
        Column {
            // Header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = language.ifBlank { "code" }.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = LadybugRed,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                )

                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("code", code))
                        copied = true
                        Toast.makeText(context, "Code copied to clipboard", Toast.LENGTH_SHORT).show()
                        scope.launch {
                            delay(2000)
                            copied = false
                        }
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("copy_code_button")
                ) {
                    Icon(
                        imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                        contentDescription = "Copy code",
                        tint = if (copied) CyanNeon else Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Code content with horizontal scroll
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = code,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    color = Color(0xFFE2E8F0),
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun MarkdownParagraph(text: String) {
    val annotatedString = remember(text) {
        buildAnnotatedString {
            var index = 0
            while (index < text.length) {
                // Inline bold **bold**
                val boldStart = text.indexOf("**", index)
                if (boldStart != -1) {
                    val boldEnd = text.indexOf("**", boldStart + 2)
                    if (boldEnd != -1) {
                        append(text.substring(index, boldStart))
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                            append(text.substring(boldStart + 2, boldEnd))
                        }
                        index = boldEnd + 2
                        continue
                    }
                }

                // Inline code `code`
                val codeStart = text.indexOf('`', index)
                if (codeStart != -1) {
                    val codeEnd = text.indexOf('`', codeStart + 1)
                    if (codeEnd != -1) {
                        append(text.substring(index, codeStart))
                        withStyle(
                            SpanStyle(
                                fontFamily = FontFamily.Monospace,
                                color = CyanNeon,
                                background = Color(0x3300E5FF)
                            )
                        ) {
                            append(text.substring(codeStart + 1, codeEnd))
                        }
                        index = codeEnd + 1
                        continue
                    }
                }

                append(text.substring(index))
                break
            }
        }
    }

    Text(
        text = annotatedString,
        style = MaterialTheme.typography.bodyMedium.copy(
            lineHeight = 22.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
    )
}

sealed class MarkdownBlock {
    data class Paragraph(val text: String) : MarkdownBlock()
    data class Code(val code: String, val language: String) : MarkdownBlock()
    data class Header(val title: String) : MarkdownBlock()
}

fun parseMarkdownBlocks(raw: String): List<MarkdownBlock> {
    val list = mutableListOf<MarkdownBlock>()
    val lines = raw.lines()
    var i = 0

    while (i < lines.size) {
        val line = lines[i]

        // Code block starts
        if (line.trimStart().startsWith("```")) {
            val lang = line.trim().removePrefix("```").trim()
            val codeLines = mutableListOf<String>()
            i++
            while (i < lines.size && !lines[i].trimStart().startsWith("```")) {
                codeLines.add(lines[i])
                i++
            }
            // skip closing ```
            if (i < lines.size) i++
            list.add(MarkdownBlock.Code(codeLines.joinToString("\n"), lang))
            continue
        }

        // Header ## or ###
        if (line.startsWith("### ")) {
            list.add(MarkdownBlock.Header(line.removePrefix("### ").trim()))
            i++
            continue
        }
        if (line.startsWith("## ")) {
            list.add(MarkdownBlock.Header(line.removePrefix("## ").trim()))
            i++
            continue
        }
        if (line.startsWith("# ")) {
            list.add(MarkdownBlock.Header(line.removePrefix("# ").trim()))
            i++
            continue
        }

        // Regular paragraph accumulator
        val paragraphLines = mutableListOf<String>()
        while (i < lines.size && !lines[i].trimStart().startsWith("```") && !lines[i].startsWith("#")) {
            paragraphLines.add(lines[i])
            i++
        }
        val paragraphText = paragraphLines.joinToString("\n").trim()
        if (paragraphText.isNotEmpty()) {
            list.add(MarkdownBlock.Paragraph(paragraphText))
        }
    }

    return list
}
