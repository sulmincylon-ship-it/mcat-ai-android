package com.example.ui.screens

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderHighlight
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.LadybugRed
import com.example.ui.theme.NoirDarkBg
import com.example.ui.theme.NoirDarkCard
import com.example.ui.theme.NoirDarkSurfaceVariant
import com.example.ui.viewmodel.MainViewModel
import java.io.OutputStream

@Composable
fun ImageStudioScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prompt by viewModel.imagePrompt.collectAsState()
    val aspectRatio by viewModel.imageAspectRatio.collectAsState()
    val isGenerating by viewModel.isGeneratingImage.collectAsState()
    val result by viewModel.generatedImageResult.collectAsState()
    val error by viewModel.imageStudioError.collectAsState()

    val ratios = listOf("1:1", "16:9", "9:16", "4:3", "3:4")

    val samplePrompts = listOf(
        "A futuristic noir black cat with glowing cyan circuits and a tiny ladybug perched on a skyscraper overlooking a neo-city",
        "A hyper-realistic golden ladybug sitting inside a cybernetic lotus flower at dawn",
        "An artistic minimalist watercolor illustration of a cat under autumn leaves"
    )

    val bitmap = remember(result) {
        result?.base64Data?.let { base64 ->
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } catch (e: Exception) {
                null
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NoirDarkBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 4.dp)
        ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Image Studio",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )
        }
        Text(
            text = "Generate original visual art powered by gemini-2.5-flash-image",
            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.6f)),
            modifier = Modifier.padding(bottom = 14.dp)
        )

        // Text prompt input
        OutlinedTextField(
            value = prompt,
            onValueChange = { viewModel.setImagePrompt(it) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("image_prompt_input"),
            placeholder = { Text("Describe the image you want to generate in detail...", color = Color.White.copy(0.4f)) },
            maxLines = 4,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NoirDarkSurfaceVariant,
                unfocusedContainerColor = NoirDarkSurfaceVariant,
                focusedBorderColor = CyanNeon,
                unfocusedBorderColor = Color(0x33FFFFFF),
                cursorColor = CyanNeon,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Sample Prompts chips
        Text(
            text = "INSPIRATION PROMPTS",
            style = MaterialTheme.typography.labelSmall.copy(color = CyanNeon, letterSpacing = 1.sp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        for (sample in samplePrompts) {
            Text(
                text = "✨ $sample",
                style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(0.7f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { viewModel.setImagePrompt(sample) }
                    .padding(vertical = 4.dp, horizontal = 6.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Aspect Ratio Selector
        Text(
            text = "ASPECT RATIO",
            style = MaterialTheme.typography.labelSmall.copy(color = CyanNeon, letterSpacing = 1.sp)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            for (ratio in ratios) {
                val isSelected = ratio == aspectRatio
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CyanNeon else Color(0xFF141624))
                        .border(1.dp, if (isSelected) CyanNeon else BorderHighlight, RoundedCornerShape(8.dp))
                        .clickable { viewModel.setImageAspectRatio(ratio) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("ratio_$ratio"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = ratio,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isSelected) Color(0xFF001F29) else Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Generate Button
        Button(
            onClick = { viewModel.generateImage() },
            enabled = prompt.isNotBlank() && !isGenerating,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("generate_image_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = CyanNeon,
                contentColor = Color(0xFF001F29)
            )
        ) {
            if (isGenerating) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color(0xFF001F29), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Creating Image with Gemini...", fontWeight = FontWeight.Bold)
            } else {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate Image", fontWeight = FontWeight.Bold)
            }
        }

        // Error message if any
        if (error != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF261019))
                    .border(1.dp, LadybugRed, RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = "⚠️ $error",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFFF8DA1))
                )
            }
        }

        // Output Result Preview
        if (bitmap != null) {
            Spacer(modifier = Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(NoirDarkCard)
                    .border(1.dp, BorderHighlight, RoundedCornerShape(16.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = "Generated art",
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.FillWidth
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { viewModel.generateImage() },
                            modifier = Modifier.testTag("regenerate_image_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Regenerate", tint = CyanNeon)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Download / Save to Gallery
                            IconButton(
                                onClick = {
                                    saveBitmapToGallery(context, bitmap)
                                },
                                modifier = Modifier.testTag("download_image_button")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = "Download", tint = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

fun saveBitmapToGallery(context: Context, bitmap: Bitmap) {
    try {
        val filename = "mcat_ai_${System.currentTimeMillis()}.png"
        val fos: OutputStream?
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MCatAI")
            }
            val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            fos = imageUri?.let { resolver.openOutputStream(it) }
        } else {
            val imagesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString()
            val image = java.io.File(imagesDir, filename)
            fos = java.io.FileOutputStream(image)
        }
        fos?.use {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)
            Toast.makeText(context, "Image saved to Pictures/MCatAI", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Saved image notice: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
