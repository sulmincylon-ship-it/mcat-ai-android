package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderHighlight
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.LadybugRed
import com.example.ui.theme.NoirDarkBg
import com.example.ui.theme.NoirDarkCard
import com.example.ui.theme.NoirDarkSurfaceVariant
import com.example.ui.viewmodel.MainViewModel

@Composable
fun VideoStudioScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val prompt by viewModel.videoPrompt.collectAsState()
    val isGenerating by viewModel.isGeneratingVideo.collectAsState()
    val jobStatus by viewModel.videoJobStatus.collectAsState()
    val error by viewModel.videoStudioError.collectAsState()

    var selectedAspect by remember { mutableStateOf("16:9") }
    var selectedResolution by remember { mutableStateOf("720p") }

    val sampleVideoPrompts = listOf(
        "A cinematic tracking shot of an obsidian cat with neon blue eyes walking across a futuristic Tokyo rooftop in rain",
        "A glowing red ladybug flying gracefully in slow motion across a field of luminous bioluminescent mushrooms at twilight",
        "A hyper-realistic camera pan across a high-tech orbital space station overlooking Earth at sunrise"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NoirDarkBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 4.dp)) {
            Icon(Icons.Default.Movie, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Video Studio",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )
        }
        Text(
            text = "Asynchronous cinematic video generation powered by Veo API (veo-3.1-fast-generate-preview)",
            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(0.6f)),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Prompt input
        OutlinedTextField(
            value = prompt,
            onValueChange = { viewModel.setVideoPrompt(it) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("video_prompt_input"),
            placeholder = { Text("Describe the cinematic video scene in natural language...", color = Color.White.copy(0.4f)) },
            maxLines = 4,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NoirDarkSurfaceVariant,
                unfocusedContainerColor = NoirDarkSurfaceVariant,
                focusedBorderColor = CyanNeon,
                unfocusedBorderColor = Color(0x33FFFFFF),
                cursorColor = CyanNeon,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Sample prompts
        Text(
            text = "SAMPLE CINEMATIC PROMPTS",
            style = MaterialTheme.typography.labelSmall.copy(color = CyanNeon, letterSpacing = 1.sp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        for (sample in sampleVideoPrompts) {
            Text(
                text = "🎬 $sample",
                style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(0.7f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { viewModel.setVideoPrompt(sample) }
                    .padding(vertical = 4.dp, horizontal = 6.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Aspect ratio selection
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("16:9", "9:16").forEach { aspect ->
                val isSelected = aspect == selectedAspect
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CyanNeon else Color(0xFF141624))
                        .border(1.dp, if (isSelected) CyanNeon else BorderHighlight, RoundedCornerShape(8.dp))
                        .clickable { selectedAspect = aspect }
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (aspect == "16:9") "Landscape (16:9)" else "Portrait (9:16)",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isSelected) Color(0xFF001F29) else Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { viewModel.generateVideo() },
            enabled = prompt.isNotBlank() && !isGenerating,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("generate_video_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = CyanNeon,
                contentColor = Color(0xFF001F29)
            )
        ) {
            if (isGenerating) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color(0xFF001F29), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Submitting Veo Job...", fontWeight = FontWeight.Bold)
            } else {
                Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate Veo Video", fontWeight = FontWeight.Bold)
            }
        }

        if (error != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF261019))
                    .border(1.dp, LadybugRed, RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(text = "⚠️ $error", style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFFF8DA1)))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Notice: Video generation uses Google Veo preview models, which require active project provisioning and quota in Google AI Studio / Google Cloud.",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(0.6f))
                    )
                }
            }
        }

        if (jobStatus != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(NoirDarkCard)
                    .border(1.dp, BorderHighlight, RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        text = "📡 Veo Job Status:",
                        style = MaterialTheme.typography.labelMedium.copy(color = CyanNeon, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = jobStatus ?: "", style = MaterialTheme.typography.bodySmall.copy(color = Color.White))
                }
            }
        }
    }
}
