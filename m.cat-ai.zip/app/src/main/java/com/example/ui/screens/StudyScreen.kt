package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AiMode
import com.example.ui.components.NavDestination
import com.example.ui.theme.BorderHighlight
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.LadybugRed
import com.example.ui.theme.NoirDarkBg
import com.example.ui.theme.NoirDarkSurfaceVariant
import com.example.ui.viewmodel.MainViewModel

@Composable
fun StudyScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var selectedSubject by remember { mutableStateOf("Mathematics") }
    var selectedAction by remember { mutableStateOf("Step-by-step Solution") }
    var topicInput by remember { mutableStateOf("") }

    val subjects = listOf("Mathematics", "Physics", "Chemistry", "Computer Science", "History", "Biology", "Economics")
    val actions = listOf("Step-by-step Solution", "Explain Concept Simply", "Generate Practice Quiz", "Make Revision Notes")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NoirDarkBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 4.dp)) {
            Icon(Icons.Default.School, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Study & Learning Mode",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )
        }
        Text(
            text = "Personalized tutoring, homework solutions, and exam prep powered by gemini-3.1-pro-preview",
            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(0.6f)),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Subject selector
        Text(text = "ACADEMIC SUBJECT", style = MaterialTheme.typography.labelSmall.copy(color = CyanNeon, letterSpacing = 1.sp))
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (subject in subjects) {
                val isSelected = subject == selectedSubject
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CyanNeon else Color(0xFF141624))
                        .border(1.dp, if (isSelected) CyanNeon else BorderHighlight, RoundedCornerShape(8.dp))
                        .clickable { selectedSubject = subject }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = subject,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isSelected) Color(0xFF001F29) else Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Action selector
        Text(text = "TUTORING ACTION", style = MaterialTheme.typography.labelSmall.copy(color = CyanNeon, letterSpacing = 1.sp))
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (action in actions) {
                val isSelected = action == selectedAction
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) LadybugRed else Color(0xFF141624))
                        .border(1.dp, if (isSelected) LadybugRed else BorderHighlight, RoundedCornerShape(8.dp))
                        .clickable { selectedAction = action }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = action,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Question / Topic text
        OutlinedTextField(
            value = topicInput,
            onValueChange = { topicInput = it },
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .testTag("study_topic_input"),
            placeholder = { Text("Enter your exercise, formula, question, or lesson topic...", color = Color.White.copy(0.4f)) },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NoirDarkSurfaceVariant,
                unfocusedContainerColor = NoirDarkSurfaceVariant,
                focusedBorderColor = CyanNeon,
                unfocusedBorderColor = Color(0x33FFFFFF),
                cursorColor = CyanNeon,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val prompt = "Subject: $selectedSubject\nMethod: $selectedAction\n\nProblem/Topic:\n$topicInput\n\nPlease provide a clear, educational, step-by-step breakdown with intuitive explanations and verified calculations."
                viewModel.setAiMode(AiMode.STUDY)
                viewModel.sendMessage(prompt)
                viewModel.navigateTo(NavDestination.CHAT)
            },
            enabled = topicInput.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("start_study_session_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = CyanNeon,
                contentColor = Color(0xFF001F29)
            )
        ) {
            Text("Begin Tutoring in Chat", fontWeight = FontWeight.Bold)
        }
    }
}
