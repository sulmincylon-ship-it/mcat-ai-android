package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.entity.ConversationEntity
import com.example.ui.theme.BorderHighlight
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.LadybugRed
import com.example.ui.theme.NoirDarkBg
import com.example.ui.theme.NoirDarkCard

enum class NavDestination(val title: String, val icon: ImageVector) {
    CHAT("Chat", Icons.Default.ChatBubbleOutline),
    IMAGE_STUDIO("Image Studio", Icons.Default.Image),
    VIDEO_STUDIO("Video Studio", Icons.Default.Movie),
    MUSIC_STUDIO("Music Studio", Icons.Default.MusicNote),
    CODING("Coding Assistant", Icons.Default.Code),
    STUDY("Study Mode", Icons.Default.School),
    SETTINGS("Settings", Icons.Default.Settings),
    ABOUT("About M.Cat AI", Icons.Default.Info)
}

@Composable
fun AppDrawerContent(
    currentDestination: NavDestination,
    onNavigate: (NavDestination) -> Unit,
    conversations: List<ConversationEntity>,
    activeConversationId: String?,
    onSelectConversation: (String) -> Unit,
    onNewChat: () -> Unit,
    onRenameConversation: (String, String) -> Unit,
    onDeleteConversation: (String) -> Unit,
    onCloseDrawer: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var renameDialogTarget by remember { mutableStateOf<ConversationEntity?>(null) }
    var renameTitleInput by remember { mutableStateOf("") }

    val filteredConversations = remember(conversations, searchQuery) {
        if (searchQuery.isBlank()) conversations
        else conversations.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(320.dp)
            .background(NoirDarkBg)
            .padding(16.dp)
    ) {
        // App Branding Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF141624))
                    .border(1.5.dp, CyanNeon, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.mcat_logo_icon_1791901699901),
                    contentDescription = "M.Cat logo",
                    modifier = Modifier.size(34.dp),
                    contentScale = ContentScale.Crop
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "M.Cat AI",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "🐞🐾", fontSize = 14.sp)
                }
                Text(
                    text = "Your Ideas. Your AI. Your World.",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = CyanNeon.copy(alpha = 0.9f)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // New Chat Button
        Button(
            onClick = {
                onNewChat()
                onNavigate(NavDestination.CHAT)
                onCloseDrawer()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("new_chat_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = CyanNeon,
                contentColor = Color(0xFF001F29)
            )
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("New Chat", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search conversations input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search conversations...", fontSize = 12.sp, color = Color.White.copy(0.4f)) },
            leadingIcon = {
                Icon(
                    Icons.Default.Search,
                    contentDescription = "Search",
                    tint = Color.White.copy(0.5f),
                    modifier = Modifier.size(16.dp)
                )
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("search_chats_input"),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF141624),
                unfocusedContainerColor = Color(0xFF141624),
                focusedBorderColor = CyanNeon,
                unfocusedBorderColor = Color(0x22FFFFFF),
                cursorColor = CyanNeon,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Navigation Destinations
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            val navItems = listOf(
                NavDestination.CHAT,
                NavDestination.IMAGE_STUDIO,
                NavDestination.VIDEO_STUDIO,
                NavDestination.MUSIC_STUDIO,
                NavDestination.CODING,
                NavDestination.STUDY
            )
            for (dest in navItems) {
                val isSelected = currentDestination == dest
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0xFF1F2538) else Color.Transparent)
                        .clickable {
                            onNavigate(dest)
                            onCloseDrawer()
                        }
                        .padding(horizontal = 10.dp, vertical = 7.dp)
                        .testTag("nav_${dest.name}"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        dest.icon,
                        contentDescription = null,
                        tint = if (isSelected) CyanNeon else Color.White.copy(0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = dest.title,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (isSelected) CyanNeon else Color.White.copy(0.9f),
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(color = Color(0x22FFFFFF))
        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "RECENT CONVERSATIONS",
            style = MaterialTheme.typography.labelSmall.copy(
                color = Color.White.copy(alpha = 0.5f),
                letterSpacing = 1.sp,
                fontSize = 10.sp
            ),
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
        )

        // List of past chats
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (filteredConversations.isEmpty()) {
                item {
                    Text(
                        text = if (searchQuery.isNotBlank()) "No matching chats" else "No conversations yet",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(0.4f)),
                        modifier = Modifier.padding(12.dp)
                    )
                }
            } else {
                items(filteredConversations, key = { it.id }) { conv ->
                    val isActive = conv.id == activeConversationId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isActive) Color(0xFF1B2134) else Color(0xFF12141F))
                            .border(
                                1.dp,
                                if (isActive) BorderHighlight else Color.Transparent,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable {
                                onSelectConversation(conv.id)
                                onNavigate(NavDestination.CHAT)
                                onCloseDrawer()
                            }
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("conversation_item_${conv.id}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.ChatBubbleOutline,
                            contentDescription = null,
                            tint = if (isActive) CyanNeon else Color.White.copy(0.4f),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = conv.title,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isActive) Color.White else Color.White.copy(0.8f)
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )

                        // Rename button
                        IconButton(
                            onClick = {
                                renameDialogTarget = conv
                                renameTitleInput = conv.title
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = "Rename",
                                tint = Color.White.copy(0.4f),
                                modifier = Modifier.size(12.dp)
                            )
                        }

                        // Delete button
                        IconButton(
                            onClick = { onDeleteConversation(conv.id) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "Delete",
                                tint = LadybugRed.copy(0.7f),
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        HorizontalDivider(color = Color(0x22FFFFFF))
        Spacer(modifier = Modifier.height(8.dp))

        // Settings and About bottom buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable {
                        onNavigate(NavDestination.SETTINGS)
                        onCloseDrawer()
                    }
                    .padding(8.dp)
                    .testTag("nav_SETTINGS"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Settings, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Settings", style = MaterialTheme.typography.bodySmall.copy(color = Color.White))
            }

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable {
                        onNavigate(NavDestination.ABOUT)
                        onCloseDrawer()
                    }
                    .padding(8.dp)
                    .testTag("nav_ABOUT"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = LadybugRed, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("About", style = MaterialTheme.typography.bodySmall.copy(color = Color.White))
            }
        }
    }

    // Rename chat dialog
    if (renameDialogTarget != null) {
        AlertDialog(
            onDismissRequest = { renameDialogTarget = null },
            title = { Text("Rename Chat", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = renameTitleInput,
                    onValueChange = { renameTitleInput = it },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyanNeon
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val target = renameDialogTarget
                        if (target != null && renameTitleInput.isNotBlank()) {
                            onRenameConversation(target.id, renameTitleInput.trim())
                        }
                        renameDialogTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanNeon, contentColor = Color(0xFF001F29))
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { renameDialogTarget = null }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = NoirDarkCard
        )
    }
}
