package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.BorderHighlight
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.LadybugRed
import com.example.ui.theme.NoirDarkBg
import com.example.ui.theme.NoirDarkCard

@Composable
fun AboutScreen(
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NoirDarkBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Large Brand Logo
        Box(
            modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(Color(0xFF141624))
                .border(2.dp, CyanNeon, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.mcat_logo_icon_1791901699901),
                contentDescription = "M.Cat logo",
                modifier = Modifier.size(70.dp),
                contentScale = ContentScale.Crop
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "M.Cat AI",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "🐞🐾", fontSize = 22.sp)
        }

        Text(
            text = "Your Ideas. Your AI. Your World.",
            style = MaterialTheme.typography.bodyMedium.copy(color = CyanNeon),
            modifier = Modifier.padding(top = 2.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Creator Spotlight Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF1B1624))
                .border(1.5.dp, LadybugRed, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "APPLICATION CREATOR & OWNER",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = LadybugRed,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Created by M.Cat noir 🐞🐾",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "\"When you ask M.Cat AI 'Who created you?' in any language, it proudly responds: 'I was created by M.Cat noir 🐞🐾.'\"",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color(0xFFFFD54F),
                        textAlign = TextAlign.Center,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Multilingual & Capabilities Specs
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(NoirDarkCard)
                .border(1.dp, BorderHighlight, RoundedCornerShape(14.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "INTELLIGENCE ENGINE SPECIFICATIONS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = CyanNeon,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.Bold
                    )
                )

                SpecRow("Conversational Core", "gemini-3.5-flash (Fast, Low Latency)")
                SpecRow("Complex STEM & Coding", "gemini-3.1-pro-preview (Deep Reasoning)")
                SpecRow("Visual Art Studio", "gemini-2.5-flash-image (High Quality)")
                SpecRow("Video Generation", "veo-3.1-fast-generate-preview (Veo Cinematic)")
                SpecRow("Audio & Music Studio", "gemini-2.5-flash-native-audio-preview-12-2025")
                SpecRow("Multilingual Engine", "English, Sinhala (සිංහල), Tamil (தமிழ்), Arabic (العربية RTL), Hindi, Bengali, Japanese, Chinese, French, Spanish, German & more")
                SpecRow("Voice Features", "Android SpeechRecognizer & Text-To-Speech")
                SpecRow("Local Database", "Room Database with full SQLite persistence")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Privacy & Security Statement
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(NoirDarkCard)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "PRIVACY & SECURITY",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(0.6f), letterSpacing = 1.sp)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "M.Cat AI respects your privacy. All chat conversations are stored securely in local app storage on your device. Zero user passwords are collected. Secrets and API keys are managed safely via AI Studio Secrets. You can export or clear your data at any time from Settings.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.White.copy(alpha = 0.8f),
                        lineHeight = 18.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "Version 1.0.0 • M.Cat noir 🐞🐾",
            style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(0.4f))
        )
    }
}

@Composable
fun SpecRow(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = CyanNeon, fontWeight = FontWeight.Bold))
        Text(text = value, style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(0.85f)))
    }
}
