package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.ConversationEntity
import com.example.data.local.entity.MessageEntity
import com.example.data.model.AiMode
import com.example.data.model.AppLanguage
import com.example.data.model.AttachedMedia
import com.example.data.remote.GeminiService
import com.example.data.remote.GeneratedAudioResult
import com.example.data.remote.GeneratedImageResult
import com.example.service.VoiceService
import com.example.ui.components.NavDestination
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.util.UUID

data class UserProfile(
    val name: String = "Guest Explorer",
    val email: String = "guest@mcat.ai",
    val isGuest: Boolean = true,
    val avatarInitials: String = "GE"
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val conversationDao = db.conversationDao()
    private val messageDao = db.messageDao()

    val voiceService = VoiceService(application)

    // UI state
    val conversations = conversationDao.getAllConversations()

    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    private val _messages = MutableStateFlow<List<MessageEntity>>(emptyList())
    val messages: StateFlow<List<MessageEntity>> = _messages.asStateFlow()

    private val _currentDestination = MutableStateFlow(NavDestination.CHAT)
    val currentDestination: StateFlow<NavDestination> = _currentDestination.asStateFlow()

    private val _currentMode = MutableStateFlow(AiMode.GENERAL)
    val currentMode: StateFlow<AiMode> = _currentMode.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(AppLanguage.AUTO)
    val selectedLanguage: StateFlow<AppLanguage> = _selectedLanguage.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(true)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    // Chat generation states
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingAssistantText = MutableStateFlow("")
    val streamingAssistantText: StateFlow<String> = _streamingAssistantText.asStateFlow()

    private val _attachedMedia = MutableStateFlow<AttachedMedia?>(null)
    val attachedMedia: StateFlow<AttachedMedia?> = _attachedMedia.asStateFlow()

    private var activeJob: Job? = null
    private var messagesJob: Job? = null

    // Image Studio State
    private val _imagePrompt = MutableStateFlow("")
    val imagePrompt: StateFlow<String> = _imagePrompt.asStateFlow()

    private val _imageAspectRatio = MutableStateFlow("1:1")
    val imageAspectRatio: StateFlow<String> = _imageAspectRatio.asStateFlow()

    private val _isGeneratingImage = MutableStateFlow(false)
    val isGeneratingImage: StateFlow<Boolean> = _isGeneratingImage.asStateFlow()

    private val _generatedImageResult = MutableStateFlow<GeneratedImageResult?>(null)
    val generatedImageResult: StateFlow<GeneratedImageResult?> = _generatedImageResult.asStateFlow()

    private val _imageStudioError = MutableStateFlow<String?>(null)
    val imageStudioError: StateFlow<String?> = _imageStudioError.asStateFlow()

    // Video Studio State
    private val _videoPrompt = MutableStateFlow("")
    val videoPrompt: StateFlow<String> = _videoPrompt.asStateFlow()

    private val _isGeneratingVideo = MutableStateFlow(false)
    val isGeneratingVideo: StateFlow<Boolean> = _isGeneratingVideo.asStateFlow()

    private val _videoJobStatus = MutableStateFlow<String?>(null)
    val videoJobStatus: StateFlow<String?> = _videoJobStatus.asStateFlow()

    private val _videoStudioError = MutableStateFlow<String?>(null)
    val videoStudioError: StateFlow<String?> = _videoStudioError.asStateFlow()

    // Music Studio State
    private val _musicPrompt = MutableStateFlow("")
    val musicPrompt: StateFlow<String> = _musicPrompt.asStateFlow()

    private val _isGeneratingMusic = MutableStateFlow(false)
    val isGeneratingMusic: StateFlow<Boolean> = _isGeneratingMusic.asStateFlow()

    private val _generatedAudioResult = MutableStateFlow<GeneratedAudioResult?>(null)
    val generatedAudioResult: StateFlow<GeneratedAudioResult?> = _generatedAudioResult.asStateFlow()

    private val _musicStudioError = MutableStateFlow<String?>(null)
    val musicStudioError: StateFlow<String?> = _musicStudioError.asStateFlow()

    init {
        // Collect recognized speech from voiceService
        viewModelScope.launch {
            voiceService.recognizedText.collect { text ->
                if (text.isNotBlank()) {
                    // Send recognized speech as message
                    sendMessage(text)
                }
            }
        }

        // Initialize first chat if needed
        viewModelScope.launch {
            ensureActiveConversation()
        }
    }

    fun navigateTo(dest: NavDestination) {
        _currentDestination.value = dest
    }

    fun setAiMode(mode: AiMode) {
        _currentMode.value = mode
    }

    fun setLanguage(language: AppLanguage) {
        _selectedLanguage.value = language
    }

    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    fun attachMedia(uri: Uri, context: Context) {
        viewModelScope.launch {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val bytes = inputStream?.readBytes() ?: return@launch
                inputStream.close()
                val mimeType = context.contentResolver.getType(uri) ?: "image/jpeg"
                val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                _attachedMedia.value = AttachedMedia(
                    uriString = uri.toString(),
                    mimeType = mimeType,
                    base64Data = base64,
                    displayName = "Image (${bytes.size / 1024} KB)"
                )
            } catch (e: Exception) {
                // handle attachment error
            }
        }
    }

    fun clearAttachment() {
        _attachedMedia.value = null
    }

    suspend fun ensureActiveConversation(): String {
        val current = _activeConversationId.value
        if (current != null) return current

        val newId = UUID.randomUUID().toString()
        val title = "New Chat ${System.currentTimeMillis() % 1000}"
        conversationDao.insertConversation(
            ConversationEntity(
                id = newId,
                title = title,
                mode = _currentMode.value.name,
                model = if (_currentMode.value == AiMode.CODING || _currentMode.value == AiMode.STUDY) {
                    GeminiService.MODEL_PRO
                } else {
                    GeminiService.MODEL_FLASH
                }
            )
        )
        selectConversation(newId)
        return newId
    }

    fun startNewConversation() {
        viewModelScope.launch {
            val newId = UUID.randomUUID().toString()
            conversationDao.insertConversation(
                ConversationEntity(
                    id = newId,
                    title = "New Chat",
                    mode = _currentMode.value.name,
                    model = GeminiService.MODEL_FLASH
                )
            )
            selectConversation(newId)
        }
    }

    fun selectConversation(id: String) {
        _activeConversationId.value = id
        messagesJob?.cancel()
        messagesJob = viewModelScope.launch {
            messageDao.getMessagesForConversation(id).collect { list ->
                _messages.value = list
            }
        }
    }

    fun renameConversation(id: String, newTitle: String) {
        viewModelScope.launch {
            conversationDao.renameConversation(id, newTitle)
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            conversationDao.deleteConversation(id)
            if (_activeConversationId.value == id) {
                _activeConversationId.value = null
                _messages.value = emptyList()
                ensureActiveConversation()
            }
        }
    }

    fun clearAllConversations() {
        viewModelScope.launch {
            conversationDao.deleteAllConversations()
            _activeConversationId.value = null
            _messages.value = emptyList()
            ensureActiveConversation()
        }
    }

    fun sendMessage(userText: String) {
        if (userText.isBlank() && _attachedMedia.value == null) return

        val media = _attachedMedia.value
        _attachedMedia.value = null // consume attachment

        viewModelScope.launch {
            val convId = ensureActiveConversation()

            // Auto title if first message
            val currentList = messageDao.getMessagesList(convId)
            if (currentList.isEmpty()) {
                val titlePreview = if (userText.length > 28) userText.take(28) + "..." else userText
                conversationDao.renameConversation(convId, titlePreview)
            }

            // Insert User Message
            val userMsg = MessageEntity(
                id = UUID.randomUUID().toString(),
                conversationId = convId,
                role = "USER",
                content = userText,
                attachedMediaBase64 = media?.base64Data,
                attachedMediaMimeType = media?.mimeType,
                attachedMediaName = media?.displayName
            )
            messageDao.insertMessage(userMsg)
            conversationDao.touchConversation(convId)

            // Start Assistant Stream
            streamResponse(
                convId = convId,
                latestPrompt = userText,
                mediaBase64 = media?.base64Data,
                mediaMime = media?.mimeType
            )
        }
    }

    private fun streamResponse(
        convId: String,
        latestPrompt: String,
        mediaBase64: String?,
        mediaMime: String?
    ) {
        activeJob?.cancel()
        _isGenerating.value = true
        _streamingAssistantText.value = ""

        activeJob = viewModelScope.launch {
            val historyEntities = messageDao.getMessagesList(convId)
            // exclude last user message since it's passed as latest
            val history = historyEntities.dropLast(1).map {
                it.role to it.content
            }

            val chosenModel = when (_currentMode.value) {
                AiMode.CODING, AiMode.STUDY -> GeminiService.MODEL_PRO
                else -> GeminiService.MODEL_FLASH
            }

            val enableSearch = _currentMode.value == AiMode.RESEARCH

            val accumulated = StringBuilder()

            GeminiService.streamChat(
                history = history,
                latestUserMessage = latestPrompt,
                attachedMediaBase64 = mediaBase64,
                attachedMediaMimeType = mediaMime,
                model = chosenModel,
                preferredLanguage = _selectedLanguage.value,
                enableSearchGrounding = enableSearch
            ).catch { e ->
                accumulated.append("\n\n⚠️ Encountered an issue: ${e.localizedMessage ?: e.message}")
                _streamingAssistantText.value = accumulated.toString()
            }.collect { chunk ->
                accumulated.append(chunk)
                _streamingAssistantText.value = accumulated.toString()
            }

            val finalContent = accumulated.toString().ifEmpty {
                "M.Cat AI is ready to assist. Please try your request again."
            }

            val assistantMsg = MessageEntity(
                id = UUID.randomUUID().toString(),
                conversationId = convId,
                role = "ASSISTANT",
                content = finalContent,
                modelUsed = chosenModel
            )
            messageDao.insertMessage(assistantMsg)
            conversationDao.touchConversation(convId)

            _isGenerating.value = false
            _streamingAssistantText.value = ""
        }
    }

    fun stopGeneration() {
        activeJob?.cancel()
        _isGenerating.value = false
        val currentStreaming = _streamingAssistantText.value
        val convId = _activeConversationId.value
        if (convId != null && currentStreaming.isNotBlank()) {
            viewModelScope.launch {
                val assistantMsg = MessageEntity(
                    id = UUID.randomUUID().toString(),
                    conversationId = convId,
                    role = "ASSISTANT",
                    content = "$currentStreaming\n\n*(Generation stopped by user)*",
                    modelUsed = GeminiService.MODEL_FLASH
                )
                messageDao.insertMessage(assistantMsg)
                _streamingAssistantText.value = ""
            }
        }
    }

    fun regenerateLatest() {
        val convId = _activeConversationId.value ?: return
        viewModelScope.launch {
            val list = messageDao.getMessagesList(convId)
            val lastUserMsg = list.lastOrNull { it.role.equals("USER", ignoreCase = true) }
            if (lastUserMsg != null) {
                // If last message was assistant, delete it
                val lastMsg = list.lastOrNull()
                if (lastMsg?.role.equals("ASSISTANT", ignoreCase = true)) {
                    lastMsg?.id?.let { messageDao.deleteMessage(it) }
                }
                streamResponse(
                    convId = convId,
                    latestPrompt = lastUserMsg.content,
                    mediaBase64 = lastUserMsg.attachedMediaBase64,
                    mediaMime = lastUserMsg.attachedMediaMimeType
                )
            }
        }
    }

    // Image Studio Actions
    fun setImagePrompt(prompt: String) { _imagePrompt.value = prompt }
    fun setImageAspectRatio(ratio: String) { _imageAspectRatio.value = ratio }

    fun generateImage() {
        val prompt = _imagePrompt.value
        if (prompt.isBlank()) return
        _isGeneratingImage.value = true
        _imageStudioError.value = null
        _generatedImageResult.value = null

        viewModelScope.launch {
            val result = GeminiService.generateImage(
                prompt = prompt,
                aspectRatio = _imageAspectRatio.value
            )
            result.onSuccess {
                _generatedImageResult.value = it
                _isGeneratingImage.value = false
            }.onFailure {
                _imageStudioError.value = it.message ?: "Failed to generate image"
                _isGeneratingImage.value = false
            }
        }
    }

    // Video Studio Actions
    fun setVideoPrompt(prompt: String) { _videoPrompt.value = prompt }

    fun generateVideo() {
        val prompt = _videoPrompt.value
        if (prompt.isBlank()) return
        _isGeneratingVideo.value = true
        _videoStudioError.value = null
        _videoJobStatus.value = "Submitting Veo video generation job..."

        viewModelScope.launch {
            val result = GeminiService.generateVideo(prompt = prompt)
            result.onSuccess { status ->
                _videoJobStatus.value = "Job created: $status\nPolling video processing..."
                _isGeneratingVideo.value = false
            }.onFailure { err ->
                _videoStudioError.value = err.message ?: "Video generation failed"
                _isGeneratingVideo.value = false
            }
        }
    }

    // Music Studio Actions
    fun setMusicPrompt(prompt: String) { _musicPrompt.value = prompt }

    fun generateMusic() {
        val prompt = _musicPrompt.value
        if (prompt.isBlank()) return
        _isGeneratingMusic.value = true
        _musicStudioError.value = null
        _generatedAudioResult.value = null

        viewModelScope.launch {
            val result = GeminiService.generateAudio(prompt = prompt)
            result.onSuccess {
                _generatedAudioResult.value = it
                _isGeneratingMusic.value = false
            }.onFailure {
                _musicStudioError.value = it.message ?: "Audio generation failed"
                _isGeneratingMusic.value = false
            }
        }
    }

    fun exportChatHistory(context: Context) {
        viewModelScope.launch {
            val convId = _activeConversationId.value ?: return@launch
            val list = messageDao.getMessagesList(convId)
            val sb = java.lang.StringBuilder()
            sb.append("# M.Cat AI Chat Export\n")
            sb.append("Created by M.Cat noir 🐞🐾\n\n")
            for (msg in list) {
                val speaker = if (msg.role == "USER") "User" else "M.Cat AI"
                sb.append("### $speaker\n${msg.content}\n\n")
            }
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "M.Cat AI Conversation Export")
                putExtra(Intent.EXTRA_TEXT, sb.toString())
            }
            context.startActivity(Intent.createChooser(intent, "Export Conversation"))
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceService.release()
    }
}
