package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AiMode
import com.example.ui.components.NavDestination
import com.example.ui.theme.BorderHighlight
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.LadybugRed
import com.example.ui.theme.NoirDarkBg
import com.example.ui.theme.NoirDarkSurfaceVariant
import com.example.ui.viewmodel.MainViewModel

@Composable
fun CodingScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var selectedLanguage by remember { mutableStateOf("Kotlin") }
    var selectedTask by remember { mutableStateOf("Debug & Fix") }
    var codeInput by remember { mutableStateOf("") }

    val languages = listOf("Kotlin", "Python", "TypeScript", "Rust", "Java", "C++", "SQL", "Go")
    val tasks = listOf("Debug & Fix", "Explain Code", "Refactor Clean Code", "Generate Unit Tests", "Optimize Speed")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NoirDarkBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 4.dp)) {
            Icon(Icons.Default.Code, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Coding Assistant",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )
        }
        Text(
            text = "Advanced software engineering, debugging, and code reasoning powered by gemini-3.1-pro-preview",
            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(0.6f)),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Language Pills
        Text(text = "PROGRAMMING LANGUAGE", style = MaterialTheme.typography.labelSmall.copy(color = CyanNeon, letterSpacing = 1.sp))
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (lang in languages) {
                val isSelected = lang == selectedLanguage
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CyanNeon else Color(0xFF141624))
                        .border(1.dp, if (isSelected) CyanNeon else BorderHighlight, RoundedCornerShape(8.dp))
                        .clickable { selectedLanguage = lang }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = lang,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isSelected) Color(0xFF001F29) else Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Task Pills
        Text(text = "ENGINEERING TASK", style = MaterialTheme.typography.labelSmall.copy(color = CyanNeon, letterSpacing = 1.sp))
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (task in tasks) {
                val isSelected = task == selectedTask
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) LadybugRed else Color(0xFF141624))
                        .border(1.dp, if (isSelected) LadybugRed else BorderHighlight, RoundedCornerShape(8.dp))
                        .clickable { selectedTask = task }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = task,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Code input box
        OutlinedTextField(
            value = codeInput,
            onValueChange = { codeInput = it },
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .testTag("code_editor_input"),
            placeholder = { Text("Paste your $selectedLanguage code or programming question here...", color = Color.White.copy(0.4f), fontFamily = FontFamily.Monospace) },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NoirDarkSurfaceVariant,
                unfocusedContainerColor = NoirDarkSurfaceVariant,
                focusedBorderColor = CyanNeon,
                unfocusedBorderColor = Color(0x33FFFFFF),
                cursorColor = CyanNeon,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val prompt = "Task: $selectedTask\nLanguage: $selectedLanguage\n\n```$selectedLanguage\n$codeInput\n```\n\nPlease analyze and execute this programming task with rigorous explanations, clean code examples, and best practices."
                viewModel.setAiMode(AiMode.CODING)
                viewModel.sendMessage(prompt)
                viewModel.navigateTo(NavDestination.CHAT)
            },
            enabled = codeInput.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("submit_code_task_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = CyanNeon,
                contentColor = Color(0xFF001F29)
            )
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Analyze & Solve in Chat", fontWeight = FontWeight.Bold)
        }
    }
}
