package com.example.ui.screens

import android.media.MediaPlayer
import android.util.Base64
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderHighlight
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.LadybugRed
import com.example.ui.theme.NoirDarkBg
import com.example.ui.theme.NoirDarkCard
import com.example.ui.theme.NoirDarkSurfaceVariant
import com.example.ui.viewmodel.MainViewModel
import java.io.File
import java.io.FileOutputStream

@Composable
fun MusicStudioScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val prompt by viewModel.musicPrompt.collectAsState()
    val isGenerating by viewModel.isGeneratingMusic.collectAsState()
    val audioResult by viewModel.generatedAudioResult.collectAsState()
    val error by viewModel.musicStudioError.collectAsState()

    var selectedGenre by remember { mutableStateOf("Synthwave Cyberpunk") }
    var selectedMood by remember { mutableStateOf("Uplifting") }
    var isPlayingAudio by remember { mutableStateOf(false) }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    val genres = listOf("Synthwave Cyberpunk", "Lo-fi Hip Hop", "Indie Pop", "Orchestral", "Ambient", "Acoustic")
    val moods = listOf("Uplifting", "Mysterious", "Calm", "Energetic", "Dark Noir")

    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer?.release()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NoirDarkBg)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 4.dp)) {
            Icon(Icons.Default.MusicNote, contentDescription = null, tint = CyanNeon, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Music Studio",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )
        }
        Text(
            text = "Generate original music and soundscapes with audio models (gemini-2.5-flash-native-audio-preview-12-2025)",
            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(0.6f)),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Prompt input
        OutlinedTextField(
            value = prompt,
            onValueChange = { viewModel.setMusicPrompt(it) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("music_prompt_input"),
            placeholder = { Text("Describe the music, melody, rhythm, or song theme...", color = Color.White.copy(0.4f)) },
            maxLines = 4,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = NoirDarkSurfaceVariant,
                unfocusedContainerColor = NoirDarkSurfaceVariant,
                focusedBorderColor = CyanNeon,
                unfocusedBorderColor = Color(0x33FFFFFF),
                cursorColor = CyanNeon,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Genre Chips
        Text(text = "GENRE", style = MaterialTheme.typography.labelSmall.copy(color = CyanNeon, letterSpacing = 1.sp))
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (genre in genres.take(3)) {
                val isSelected = genre == selectedGenre
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) CyanNeon else Color(0xFF141624))
                        .border(1.dp, if (isSelected) CyanNeon else BorderHighlight, RoundedCornerShape(8.dp))
                        .clickable {
                            selectedGenre = genre
                            viewModel.setMusicPrompt("Create a $genre track with $selectedMood vibes, featuring rich melody and textures.")
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = genre,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (isSelected) Color(0xFF001F29) else Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Mood Chips
        Text(text = "MOOD", style = MaterialTheme.typography.labelSmall.copy(color = CyanNeon, letterSpacing = 1.sp))
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (mood in moods) {
                val isSelected = mood == selectedMood
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) LadybugRed else Color(0xFF141624))
                        .border(1.dp, if (isSelected) LadybugRed else BorderHighlight, RoundedCornerShape(8.dp))
                        .clickable {
                            selectedMood = mood
                            viewModel.setMusicPrompt("Create a $selectedGenre track with $mood mood and melodic beats.")
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = mood,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { viewModel.generateMusic() },
            enabled = prompt.isNotBlank() && !isGenerating,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("generate_music_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = CyanNeon,
                contentColor = Color(0xFF001F29)
            )
        ) {
            if (isGenerating) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color(0xFF001F29), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Synthesizing Audio...", fontWeight = FontWeight.Bold)
            } else {
                Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate Music", fontWeight = FontWeight.Bold)
            }
        }

        if (error != null) {
            Spacer(modifier = Modifier.height(12.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF261019))
                    .border(1.dp, LadybugRed, RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Text(text = "⚠️ $error", style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFFF8DA1)))
            }
        }

        // Generated Audio Player Card
        if (audioResult != null) {
            Spacer(modifier = Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(NoirDarkCard)
                    .border(1.dp, BorderHighlight, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "🎵 Generated Audio Track",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = "Format: ${audioResult?.mimeType}",
                            style = MaterialTheme.typography.bodySmall.copy(color = CyanNeon)
                        )
                    }

                    IconButton(
                        onClick = {
                            if (isPlayingAudio) {
                                mediaPlayer?.stop()
                                isPlayingAudio = false
                            } else {
                                val bytes = Base64.decode(audioResult?.base64Data, Base64.DEFAULT)
                                val tempFile = File.createTempFile("mcat_audio", ".mp3", context.cacheDir)
                                FileOutputStream(tempFile).use { it.write(bytes) }
                                mediaPlayer?.release()
                                mediaPlayer = MediaPlayer().apply {
                                    setDataSource(tempFile.absolutePath)
                                    prepare()
                                    start()
                                    setOnCompletionListener {
                                        isPlayingAudio = false
                                    }
                                }
                                isPlayingAudio = true
                            }
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(CyanNeon)
                    ) {
                        Icon(
                            imageVector = if (isPlayingAudio) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlayingAudio) "Pause" else "Play",
                            tint = Color(0xFF001F29)
                        )
                    }
                }
            }
        }
    }
}
