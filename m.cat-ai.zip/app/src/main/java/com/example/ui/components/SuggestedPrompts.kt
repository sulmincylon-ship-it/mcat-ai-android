package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderHighlight
import com.example.ui.theme.CyanNeon

data class PromptSuggestion(
    val title: String,
    val prompt: String,
    val icon: String
)

val DEFAULT_PROMPTS = listOf(
    PromptSuggestion("Creator Info", "Who created you?", "🐾"),
    PromptSuggestion("Coding Assistant", "Write a clean Kotlin coroutine retry function with exponential backoff.", "💻"),
    PromptSuggestion("Study & Math", "Explain Bayes' theorem step-by-step with an intuitive real-world example.", "🎓"),
    PromptSuggestion("Sinhala AI", "කෘත්‍රිම බුද්ධිය (AI) මගින් අපේ ලෝකය වෙනස් වන්නේ කෙසේදැයි පැහැදිලි කරන්න.", "🇱🇰"),
    PromptSuggestion("Tamil AI", "செயற்கை நுண்ணறிவு தொழில்நுட்பத்தின் எதிர்காலம் பற்றி விளக்குங்கள்.", "🇮🇳"),
    PromptSuggestion("Arabic AI", "اشرح لي أساسيات تعلم الآلة بأسلوب مبسط.", "🌍"),
    PromptSuggestion("Creative Poem", "Write an atmospheric noir cyberpunk poem featuring a detective cat.", "✨")
)

@Composable
fun SuggestedPromptRow(
    onSelectPrompt: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Text(
            text = "Suggested Prompts",
            style = MaterialTheme.typography.labelSmall.copy(
                color = CyanNeon.copy(alpha = 0.8f),
                letterSpacing = 0.5.sp
            ),
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (item in DEFAULT_PROMPTS) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF161826))
                        .border(1.dp, BorderHighlight, RoundedCornerShape(16.dp))
                        .clickable { onSelectPrompt(item.prompt) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("prompt_chip_${item.title}"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(text = item.icon, fontSize = 14.sp)
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        )
                    }
                }
            }
        }
    }
}
