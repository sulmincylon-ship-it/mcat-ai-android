package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Noir Base
val NoirDarkBg = Color(0xFF0C0D14)
val NoirDarkSurface = Color(0xFF141622)
val NoirDarkSurfaceVariant = Color(0xFF1D2032)
val NoirDarkCard = Color(0xFF23273D)

// Neon & Ladybug Accents
val CyanNeon = Color(0xFF00E5FF)
val CyanNeonVariant = Color(0xFF00B0FF)
val LadybugRed = Color(0xFFFF3366)
val LadybugCrimson = Color(0xFFE91E63)
val LadybugGold = Color(0xFFFFD54F)

// Light Theme Palettes
val LightBg = Color(0xFFF7F8FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF1F8)
val LightCard = Color(0xFFE3E7F3)

// Text and On-Colors
val TextWhitePrimary = Color(0xFFF1F5F9)
val TextWhiteSecondary = Color(0xFF94A3B8)
val TextDarkPrimary = Color(0xFF0F172A)
val TextDarkSecondary = Color(0xFF64748B)

val CodeBlockBg = Color(0xFF0B0D13)
val BorderHighlight = Color(0x3300E5FF)
val LadybugBorder = Color(0x33FF3366)
